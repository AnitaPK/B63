import React from 'react'

const Asidebar = () => {
  return (
    <div>
      sidebar
    </div>
  )
}

export default Asidebar
