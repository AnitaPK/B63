import React from 'react'

const BestSellers = () => {
  return (
    <div className='bg-dark text-white ' style={{height:"500px"}}>
      <h1 className='text-center'>Higher Selling Products</h1>
      
    </div>
  )
}

export default BestSellers
